<hr>
<footer style=" bottom: 0; width: 100%; text-align: center;">
Copyright @ 2024 Sistem Kehadiran Pertandingan Golf Antarabangsa 2024 dianjurkan oleh Epsilon Golf Association dengan kerjasama
 Kementerian Kesukanan Malaysia dan Persatuan Golf Malaysia
</footer>