<?php
#memulakan fungsi session
session_start();

#memanggil fail header.php 
include('header.php');
?>
<html>
    <div class ="wrapper">
        <div class ="main-content">
            <table width = '100%'  >
    <tr>
        <td width='70%' bgcolor='#7CB9E8'>
            <img src='https://images-platform.99static.com//IXieMAprzvTSr5ykSitWbjq0LQI=/330x363:1186x1219/fit-in/590x590/99designs-contests-attachments/96/96851/attachment_96851075' width='100%'>
        </td>
        <td align='center' bgcolor='#56a337'>
        <h3>Daftar Sebagai Peserta</h3>
        <h3>Klik Pautan Dibawah Untuk Mendaftar</h3>
        <a href='signup-borang.php'>Daftar Sini</a>
    </td>
    </tr>
        </table>
        </div>
    </div>
<?php include ('footer.php'); ?>
</html>
